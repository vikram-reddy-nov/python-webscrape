var  config = require('./dbconfig');
const  sql = require('mssql');

async  function  getData(conditions) {
    try {
      let condition1 = "";
      let condition2 = "";
      conditions.forEach(condition => {
        if(condition.year) {
            condition1 = " and year="+condition.year;
        }
        if(condition.order) {
            condition2 = " sort by sold_price "+ condition.order;
        }
      });
      let  pool = await  sql.connect(config);
      let  pokemon = await  pool.request().query("SELECT * from scrape_dataset where image_downloaded=1 " + condition1 + condition2 +" limit 50");
      return  pokemon.recordsets;
    }
    catch (error) {
      console.log(error);
    }
  }

  module.exports = {
    getData:  getData
  }